import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    role: "LEARNER",
    password: "",
    confirmPassword: "",
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setMessage("Passwords do not match!");
      return;
    }

    const userPayload = {
      userName: formData.fullName,
      userRole: formData.role,
      passWord: formData.password,
    };

    try {
      const response = await fetch("http://localhost:8080/users-details/create-users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userPayload),
      });

      if (response.ok) {
        setMessage("User registered successfully!");
        setFormData({ fullName: "", role: "LEARNER", password: "", confirmPassword: "" });
      } else {
        setMessage("Failed to register user!");
      }
    } catch (error) {
      console.error("Error:", error);
      setMessage("Server error! Please try again.");
    }
  };

  return (
    <div className="register-container">
      <div className="overlay">
        <div className="card p-4 shadow-lg" style={{ width: "350px" }}>
          <h2 className="text-center mb-4 text-dark">Register</h2>

          {message && <p className="alert alert-info text-center">{message}</p>}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label text-white">Full Name</label>
              <input
                type="text"
                name="fullName"
                className="form-control"
                placeholder="Enter your name"
                value={formData.fullName}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label className="form-label text-white">Role</label>
              <select
                name="role"
                className="form-select"
                value={formData.role}
                onChange={handleChange}
                required
              >
                <option value="AUTHOR">Author</option>
                <option value="ADMIN">Admin</option>
                <option value="LEARNER">Learner</option>
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label text-white">Password</label>
              <input
                type="password"
                name="password"
                className="form-control"
                placeholder="Enter your password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label className="form-label text-white">Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                className="form-control"
                placeholder="Confirm password"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
              />
            </div>

            <button type="submit" className="btn btn-dark w-100">Register</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;
